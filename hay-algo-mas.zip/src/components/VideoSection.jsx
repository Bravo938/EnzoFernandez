import { useState } from "react";
import { FaPlay } from "react-icons/fa";
import AnimatedContainer from "./AnimatedContainer";
import GlassPanel from "./GlassPanel";
import ButtonPrimary from "./ButtonPrimary";

// Pantalla 6: el iframe de YouTube NO se monta hasta que el usuario
// hace click en "Escuchar su testimonio". Esto evita cargar recursos
// pesados de YouTube antes de que el usuario los pida (mejor rendimiento).
export default function VideoSection({ youtubeId, title }) {
  const [videoLoaded, setVideoLoaded] = useState(false);

  return (
    <section className="relative flex min-h-screen w-full flex-col items-center justify-center px-6 py-24 text-center">
      <AnimatedContainer className="w-full max-w-lg">
        {!videoLoaded ? (
          <GlassPanel className="flex aspect-video w-full flex-col items-center justify-center gap-6 p-8">
            <p className="text-balance font-body text-mist/70">
              Escuchá, en sus propias palabras, cómo cambió su historia.
            </p>
            <ButtonPrimary
              icon={FaPlay}
              onClick={() => setVideoLoaded(true)}
              aria-label={`Reproducir: ${title}`}
            >
              Escuchar su testimonio
            </ButtonPrimary>
          </GlassPanel>
        ) : (
          <GlassPanel className="aspect-video w-full overflow-hidden p-0">
            <iframe
              className="h-full w-full rounded-3xl"
              src={`https://www.youtube.com/embed/${youtubeId}?autoplay=1`}
              title={title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              loading="lazy"
            />
          </GlassPanel>
        )}
      </AnimatedContainer>
    </section>
  );
}
